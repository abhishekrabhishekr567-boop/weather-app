import { useState, useEffect } from "react";
import { Location } from "@/lib/api";

const HISTORY_KEY = "weather_search_history";

export function useSearchHistory() {
  const [history, setHistory] = useState<Location[]>(() => {
    try {
      const item = localStorage.getItem(HISTORY_KEY);
      return item ? JSON.parse(item) : [];
    } catch {
      return [];
    }
  });

  const addToHistory = (location: Location) => {
    setHistory((prev) => {
      // Remove if already exists
      const filtered = prev.filter((loc) => loc.id !== location.id);
      // Add to front
      const newHistory = [location, ...filtered].slice(0, 5); // Keep last 5
      localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
      return newHistory;
    });
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem(HISTORY_KEY);
  };

  return { history, addToHistory, clearHistory };
}
