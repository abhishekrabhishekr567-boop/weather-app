import { useQuery } from "@tanstack/react-query";
import { getWeatherData, searchLocations, reverseGeocode, Location } from "@/lib/api";

export function useWeather(location: Location | null) {
  return useQuery({
    queryKey: ["weather", location?.id, location?.latitude, location?.longitude],
    queryFn: () => {
      if (!location) throw new Error("No location provided");
      return getWeatherData(location.latitude, location.longitude);
    },
    enabled: !!location,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

export function useLocationSearch(query: string) {
  return useQuery({
    queryKey: ["locations", query],
    queryFn: () => searchLocations(query),
    enabled: query.trim().length > 1,
    staleTime: 60 * 60 * 1000,
  });
}

export function useReverseGeocode(lat: number | null, lon: number | null) {
  return useQuery({
    queryKey: ["reverse-geocode", lat, lon],
    queryFn: () => {
      if (lat === null || lon === null) throw new Error("Missing coords");
      return reverseGeocode(lat, lon);
    },
    enabled: lat !== null && lon !== null,
    staleTime: Infinity,
  });
}
