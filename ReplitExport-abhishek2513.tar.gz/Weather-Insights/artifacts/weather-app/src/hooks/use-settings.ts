import { useState, useEffect } from "react";

type Unit = "C" | "F";
type Theme = "light" | "dark" | "system";

export function useSettings() {
  const [unit, setUnit] = useState<Unit>(() => {
    return (localStorage.getItem("weather_unit") as Unit) || "C";
  });

  const [theme, setTheme] = useState<Theme>(() => {
    return (localStorage.getItem("weather_theme") as Theme) || "system";
  });

  useEffect(() => {
    localStorage.setItem("weather_unit", unit);
  }, [unit]);

  useEffect(() => {
    localStorage.setItem("weather_theme", theme);
    const root = window.document.documentElement;
    root.classList.remove("light", "dark");
    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme);
    }
  }, [theme]);

  const toggleUnit = () => setUnit((prev) => (prev === "C" ? "F" : "C"));

  return { unit, theme, setUnit, setTheme, toggleUnit };
}
