import { Location, WeatherData } from "@/lib/api";
import { getWeatherCondition, formatTemp } from "@/lib/weather";
import { MapPin } from "lucide-react";

interface CurrentWeatherProps {
  weather: WeatherData;
  location: Location;
  unit: "C" | "F";
}

export function CurrentWeather({ weather, location, unit }: CurrentWeatherProps) {
  const current = weather.current;
  const condition = getWeatherCondition(current.weather_code, current.is_day);
  const Icon = condition.icon;

  return (
    <div className="flex flex-col items-center justify-center py-8 px-4 text-center animate-in fade-in slide-in-from-bottom-4 duration-700 ease-out">
      <div className="flex items-center gap-1.5 text-lg font-medium tracking-tight mb-2 opacity-90">
        <MapPin className="w-5 h-5" />
        <h2>{location.name}</h2>
      </div>
      
      <p className="text-sm opacity-80 mb-6 font-medium tracking-wide">
        {location.admin1 ? `${location.admin1}, ` : ''}{location.country}
      </p>

      <div className="relative mb-6 drop-shadow-xl transform transition-transform hover:scale-105 duration-500">
        <div className="absolute inset-0 blur-2xl opacity-40 bg-current rounded-full"></div>
        <Icon className="w-32 h-32 relative z-10" strokeWidth={1.5} />
      </div>

      <h1 className="text-8xl font-bold tracking-tighter mb-2 font-sans tabular-nums">
        {formatTemp(current.temperature_2m, unit)}
      </h1>
      
      <div className="flex items-center justify-center gap-3">
        <span className="text-2xl font-medium tracking-tight opacity-90">{condition.label}</span>
      </div>
      
      <div className="mt-4 flex gap-4 text-sm font-medium opacity-80 bg-black/5 dark:bg-white/5 px-4 py-1.5 rounded-full">
        <span>H: {formatTemp(weather.daily.temperature_2m_max[0], unit)}</span>
        <div className="w-px h-4 bg-current opacity-20"></div>
        <span>L: {formatTemp(weather.daily.temperature_2m_min[0], unit)}</span>
      </div>
    </div>
  );
}
