import React, { useState, useEffect, useRef } from "react";
import { Search, MapPin, X, Loader2, Clock, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useDebounce } from "@/hooks/use-debounce";
import { useLocationSearch } from "@/hooks/use-weather";
import { Location } from "@/lib/api";
import { useSearchHistory } from "@/hooks/use-search-history";

interface SearchBarProps {
  onSelect: (location: Location) => void;
  onUseLocation: () => void;
  isLocating: boolean;
}

export function SearchBar({ onSelect, onUseLocation, isLocating }: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const { history, addToHistory, clearHistory } = useSearchHistory();
  
  const debouncedQuery = useDebounce(query, 500);
  const { data: results, isLoading, isError } = useLocationSearch(debouncedQuery);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelect = (loc: Location) => {
    addToHistory(loc);
    onSelect(loc);
    setQuery("");
    setIsOpen(false);
  };

  const showHistory = query.trim().length === 0 && history.length > 0;
  const showResults = query.trim().length > 1;

  return (
    <div ref={wrapperRef} className="relative w-full max-w-md mx-auto z-50">
      <div className="relative group">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <Search className="h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
        </div>
        <Input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder="Search for a city..."
          className="pl-10 pr-12 h-12 rounded-full glass-panel-heavy border-white/40 shadow-md text-base focus-visible:ring-primary focus-visible:ring-offset-2 transition-all placeholder:text-muted-foreground/70"
        />
        <div className="absolute inset-y-0 right-1 flex items-center">
          {query.length > 0 ? (
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-full text-muted-foreground hover:text-foreground"
              onClick={() => {
                setQuery("");
                setIsOpen(true);
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
              onClick={onUseLocation}
              disabled={isLocating}
              title="Use current location"
            >
              {isLocating ? <Loader2 className="h-4 w-4 animate-spin" /> : <MapPin className="h-4 w-4" />}
            </Button>
          )}
        </div>
      </div>

      {isOpen && (showHistory || showResults) && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-card/95 backdrop-blur-xl border rounded-2xl shadow-xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
          
          {showHistory && !showResults && (
            <div className="p-2">
              <div className="flex items-center justify-between px-3 py-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
                <span className="flex items-center gap-1.5"><Clock className="w-3 h-3" /> Recent Searches</span>
                <button onClick={clearHistory} className="hover:text-destructive transition-colors flex items-center gap-1">
                  <Trash2 className="w-3 h-3" /> Clear
                </button>
              </div>
              <div className="flex flex-col gap-1 mt-1">
                {history.map((loc) => (
                  <button
                    key={`hist-${loc.id}`}
                    className="flex flex-col items-start px-3 py-2 hover:bg-primary/5 rounded-xl transition-colors text-left"
                    onClick={() => handleSelect(loc)}
                  >
                    <span className="font-medium text-sm text-foreground">{loc.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {loc.admin1 ? `${loc.admin1}, ` : ''}{loc.country}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {showResults && (
            <div className="p-2">
              <div className="px-3 py-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Results
              </div>
              
              {isLoading && (
                <div className="flex items-center justify-center p-4">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              )}
              
              {isError && (
                <div className="px-3 py-4 text-sm text-destructive text-center">
                  Failed to load results. Please try again.
                </div>
              )}
              
              {!isLoading && !isError && results?.length === 0 && (
                <div className="px-3 py-4 text-sm text-muted-foreground text-center">
                  No cities found for "{query}"
                </div>
              )}
              
              {!isLoading && !isError && results && results.length > 0 && (
                <div className="flex flex-col gap-1 mt-1 max-h-[300px] overflow-y-auto">
                  {results.map((loc) => (
                    <button
                      key={`res-${loc.id}`}
                      className="flex flex-col items-start px-3 py-2.5 hover:bg-primary/5 rounded-xl transition-colors text-left"
                      onClick={() => handleSelect(loc)}
                    >
                      <span className="font-medium text-sm text-foreground">{loc.name}</span>
                      <span className="text-xs text-muted-foreground">
                        {loc.admin1 ? `${loc.admin1}, ` : ''}{loc.country}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
