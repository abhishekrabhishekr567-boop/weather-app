import { WeatherData } from "@/lib/api";
import { formatTemp, formatTime } from "@/lib/weather";
import { Thermometer, Droplets, Wind, Sunrise, Sunset, Eye } from "lucide-react";

interface WeatherDetailsProps {
  weather: WeatherData;
  unit: "C" | "F";
}

export function WeatherDetails({ weather, unit }: WeatherDetailsProps) {
  const current = weather.current;
  const today = weather.daily;

  const details = [
    {
      label: "Feels Like",
      icon: Thermometer,
      value: formatTemp(current.apparent_temperature, unit),
      desc: current.apparent_temperature > current.temperature_2m ? "Warmer than actual" : "Colder than actual"
    },
    {
      label: "Humidity",
      icon: Droplets,
      value: `${current.relative_humidity_2m}%`,
      desc: "Dew point is near"
    },
    {
      label: "Wind Speed",
      icon: Wind,
      value: `${current.wind_speed_10m} km/h`,
      desc: "Current speed"
    },
    {
      label: "Sunrise",
      icon: Sunrise,
      value: formatTime(today.sunrise[0]),
      desc: "Morning"
    },
    {
      label: "Sunset",
      icon: Sunset,
      value: formatTime(today.sunset[0]),
      desc: "Evening"
    },
    {
      label: "Precipitation",
      icon: Eye, // placeholder for a generic icon or droplet
      value: `${current.precipitation} mm`,
      desc: "Last hour"
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-300 fill-mode-both">
      {details.map((item, i) => {
        const Icon = item.icon;
        return (
          <div key={item.label} className="glass-panel rounded-3xl p-4 flex flex-col gap-2 hover:bg-white/50 dark:hover:bg-black/50 transition-colors duration-300">
            <div className="flex items-center gap-1.5 opacity-70">
              <Icon className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase tracking-wider">{item.label}</span>
            </div>
            <div className="text-2xl font-semibold tabular-nums mt-1">{item.value}</div>
            <div className="text-xs opacity-60 mt-auto font-medium">{item.desc}</div>
          </div>
        );
      })}
    </div>
  );
}
