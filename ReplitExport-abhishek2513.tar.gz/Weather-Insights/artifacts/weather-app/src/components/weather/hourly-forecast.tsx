import { WeatherData } from "@/lib/api";
import { formatTemp, getWeatherCondition } from "@/lib/weather";
import { Droplets } from "lucide-react";

interface HourlyForecastProps {
  weather: WeatherData;
  unit: "C" | "F";
}

export function HourlyForecast({ weather, unit }: HourlyForecastProps) {
  // Get next 24 hours starting from current hour
  const currentHourString = weather.current.time;
  // Open-meteo provides time as exact ISO strings in hourly array. Find index of current hour
  // If not exact match, find closest past hour.
  const currentTimeMs = new Date(currentHourString).getTime();
  
  let startIndex = 0;
  for (let i = 0; i < weather.hourly.time.length; i++) {
    const timeMs = new Date(weather.hourly.time[i]).getTime();
    if (timeMs >= currentTimeMs) {
      startIndex = i;
      break;
    }
  }

  // Slice next 24 hours
  const endIndex = Math.min(startIndex + 24, weather.hourly.time.length);
  const hours = weather.hourly.time.slice(startIndex, endIndex);
  const temps = weather.hourly.temperature_2m.slice(startIndex, endIndex);
  const codes = weather.hourly.weather_code.slice(startIndex, endIndex);
  const precipProbs = weather.hourly.precipitation_probability.slice(startIndex, endIndex);

  // We assume all hourly forecasts are daytime icons for simplicity, except we could compute isNight based on sunset/sunrise.
  // We'll just pass 1 (day) since Open-Meteo hourly doesn't give is_day array directly without requesting it.

  return (
    <div className="glass-panel-heavy rounded-3xl p-5 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100 fill-mode-both">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-sm tracking-wide uppercase opacity-70">Today</h3>
      </div>
      
      <div className="flex gap-4 overflow-x-auto pb-4 pt-2 -mx-2 px-2 scrollbar-hide snap-x">
        {hours.map((timeStr, i) => {
          const date = new Date(timeStr);
          const isNow = i === 0;
          const label = isNow ? "Now" : date.toLocaleTimeString([], { hour: 'numeric' });
          const condition = getWeatherCondition(codes[i], 1); // Simple daytime icon for hourly
          const Icon = condition.icon;
          const precip = precipProbs[i];
          
          return (
            <div 
              key={timeStr} 
              className="flex flex-col items-center justify-between min-w-[4.5rem] gap-3 snap-center"
            >
              <span className={`text-sm font-medium ${isNow ? 'opacity-100' : 'opacity-70'}`}>
                {label}
              </span>
              
              <div className="relative">
                <Icon className="w-7 h-7 opacity-90" />
                {precip > 0 && (
                  <div className="flex flex-col items-center mt-1 text-[10px] text-blue-400 dark:text-blue-300 font-bold">
                    <span>{precip}%</span>
                  </div>
                )}
              </div>
              
              <span className="text-base font-semibold tabular-nums mt-auto">
                {formatTemp(temps[i], unit)}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
