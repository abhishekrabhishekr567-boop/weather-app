import { useEffect, useState } from "react";
import { SearchBar } from "./search-bar";
import { CurrentWeather } from "./current-weather";
import { HourlyForecast } from "./hourly-forecast";
import { DailyForecast } from "./daily-forecast";
import { WeatherDetails } from "./weather-details";
import { useWeather, useReverseGeocode } from "@/hooks/use-weather";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useSettings } from "@/hooks/use-settings";
import { Location } from "@/lib/api";
import { Moon, Sun, Cloud, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getWeatherCondition } from "@/lib/weather";
import { useToast } from "@/hooks/use-toast";

const DEFAULT_LOCATION: Location = {
  id: 5391959,
  name: "San Francisco",
  latitude: 37.7749,
  longitude: -122.4194,
  country: "United States",
  admin1: "California",
  timezone: "America/Los_Angeles"
};

export default function WeatherApp() {
  const [location, setLocation] = useState<Location>(DEFAULT_LOCATION);
  const { unit, theme, toggleUnit, setTheme } = useSettings();
  const { toast } = useToast();
  
  const { data: weather, isLoading, isError, error } = useWeather(location);
  const { coords, error: geoError, isLoading: isLocating, requestLocation } = useGeolocation();
  const { data: geoLoc } = useReverseGeocode(coords?.lat ?? null, coords?.lon ?? null);

  useEffect(() => {
    if (geoLoc) {
      setLocation(geoLoc);
      toast({
        title: "Location updated",
        description: `Showing weather for ${geoLoc.name}`,
      });
    }
  }, [geoLoc, toast]);

  useEffect(() => {
    if (geoError) {
      toast({
        title: "Location error",
        description: geoError,
        variant: "destructive"
      });
    }
  }, [geoError, toast]);

  // Determine dynamic background gradient based on current weather condition
  let bgClasses = "bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-900 dark:to-slate-950";
  let textClasses = "text-slate-900 dark:text-slate-100";

  if (weather) {
    const condition = getWeatherCondition(weather.current.weather_code, weather.current.is_day);
    // In actual dark mode, we force the dark variant of the theme gradient
    bgClasses = `bg-gradient-to-br ${condition.colorTheme.light} dark:${condition.colorTheme.dark.split(' ').join(' dark:')}`;
    textClasses = weather.current.is_day && theme !== 'dark' ? "text-slate-900" : "text-white";
  }

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <div className={`min-h-[100dvh] w-full transition-all duration-1000 ease-in-out ${bgClasses} ${textClasses}`}>
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none mix-blend-overlay"></div>
      
      <div className="relative z-10 container max-w-4xl mx-auto px-4 py-8 flex flex-col min-h-[100dvh]">
        
        {/* Header / Controls */}
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2 font-bold tracking-tight">
            <Cloud className="w-6 h-6" />
            <span className="hidden sm:inline">Weather Now</span>
          </div>
          
          <div className="flex-1 max-w-md mx-4">
            <SearchBar 
              onSelect={setLocation} 
              onUseLocation={requestLocation}
              isLocating={isLocating}
            />
          </div>

          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme}
              className="rounded-full hover:bg-black/10 dark:hover:bg-white/10 glass-panel border-none shadow-none"
            >
              {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={toggleUnit}
              className="rounded-full font-bold w-10 px-0 hover:bg-black/10 dark:hover:bg-white/10 glass-panel border-none shadow-none"
            >
              °{unit}
            </Button>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 flex flex-col gap-6">
          {isLoading && (
            <div className="flex-1 flex flex-col items-center justify-center min-h-[50vh] opacity-70 animate-pulse">
              <Loader2 className="w-12 h-12 animate-spin mb-4" />
              <p className="font-medium tracking-wide">Gathering weather data...</p>
            </div>
          )}

          {isError && (
            <div className="flex-1 flex flex-col items-center justify-center min-h-[50vh] text-center">
              <div className="glass-panel p-8 rounded-3xl max-w-md">
                <h2 className="text-xl font-bold mb-2">Data Unavailable</h2>
                <p className="opacity-80 mb-6">{error?.message || "Failed to fetch weather data. Please try again."}</p>
                <Button onClick={() => window.location.reload()} variant="outline" className="rounded-full">
                  Retry
                </Button>
              </div>
            </div>
          )}

          {!isLoading && !isError && weather && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
              {/* Left Column - Current */}
              <div className="lg:col-span-5 flex flex-col justify-center">
                <CurrentWeather weather={weather} location={location} unit={unit} />
              </div>
              
              {/* Right Column - Forecasts & Details */}
              <div className="lg:col-span-7 flex flex-col gap-6">
                <HourlyForecast weather={weather} unit={unit} />
                <WeatherDetails weather={weather} unit={unit} />
                <DailyForecast weather={weather} unit={unit} />
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
