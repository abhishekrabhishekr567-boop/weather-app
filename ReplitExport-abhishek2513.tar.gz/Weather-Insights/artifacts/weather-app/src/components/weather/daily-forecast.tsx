import { WeatherData } from "@/lib/api";
import { formatTemp, getWeatherCondition } from "@/lib/weather";
import { Calendar } from "lucide-react";

interface DailyForecastProps {
  weather: WeatherData;
  unit: "C" | "F";
}

export function DailyForecast({ weather, unit }: DailyForecastProps) {
  const { daily } = weather;
  
  return (
    <div className="glass-panel-heavy rounded-3xl p-5 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200 fill-mode-both">
      <div className="flex items-center gap-2 mb-5">
        <Calendar className="w-4 h-4 opacity-70" />
        <h3 className="font-semibold text-sm tracking-wide uppercase opacity-70">7-Day Forecast</h3>
      </div>
      
      <div className="flex flex-col gap-1">
        {daily.time.map((timeStr, i) => {
          const date = new Date(timeStr);
          const isToday = i === 0;
          const label = isToday ? "Today" : date.toLocaleDateString([], { weekday: 'long' });
          const condition = getWeatherCondition(daily.weather_code[i], 1);
          const Icon = condition.icon;
          
          // Calculate a simple visual bar for temp range
          // Find absolute min and max of the week to scale the bars
          const weekMin = Math.min(...daily.temperature_2m_min);
          const weekMax = Math.max(...daily.temperature_2m_max);
          const weekRange = weekMax - weekMin;
          
          const dayMin = daily.temperature_2m_min[i];
          const dayMax = daily.temperature_2m_max[i];
          
          const leftPercent = ((dayMin - weekMin) / weekRange) * 100;
          const widthPercent = ((dayMax - dayMin) / weekRange) * 100;

          return (
            <div key={timeStr} className="flex items-center py-3 border-b border-white/5 last:border-0">
              <span className="w-24 text-base font-medium opacity-90">{label}</span>
              
              <div className="flex-1 flex justify-center">
                <Icon className="w-6 h-6 opacity-80" />
              </div>
              
              <div className="flex items-center justify-end w-40 gap-3">
                <span className="text-sm font-semibold tabular-nums opacity-70 w-8 text-right">
                  {formatTemp(dayMin, unit)}
                </span>
                
                <div className="w-20 h-1.5 rounded-full bg-black/10 dark:bg-white/10 relative overflow-hidden">
                  <div 
                    className="absolute h-full rounded-full bg-gradient-to-r from-blue-400 to-orange-400 opacity-80"
                    style={{ left: `${leftPercent}%`, width: `${widthPercent}%` }}
                  />
                </div>
                
                <span className="text-sm font-semibold tabular-nums opacity-100 w-8 text-right">
                  {formatTemp(dayMax, unit)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
