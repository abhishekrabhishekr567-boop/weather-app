import { Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudRain, CloudSnow, CloudSun, Snowflake, Sun, Moon, Wind } from "lucide-react";

export interface WeatherCondition {
  label: string;
  icon: any; // Lucide icon
  colorTheme: {
    light: string; // Gradient from/to
    dark: string;
  };
}

export function getWeatherCondition(code: number, isDay: number = 1): WeatherCondition {
  // WMO Weather interpretation codes (WW)
  // https://open-meteo.com/en/docs
  
  const isNight = isDay === 0;

  switch (code) {
    case 0: // Clear sky
      return {
        label: "Clear",
        icon: isNight ? Moon : Sun,
        colorTheme: isNight 
          ? { light: "from-indigo-900 to-slate-900", dark: "from-indigo-950 to-slate-950" }
          : { light: "from-sky-300 to-amber-200", dark: "from-sky-800 to-amber-900/40" },
      };
    case 1: // Mainly clear
    case 2: // Partly cloudy
    case 3: // Overcast
      return {
        label: code === 3 ? "Overcast" : "Partly Cloudy",
        icon: code === 3 ? Cloud : (isNight ? Cloud : CloudSun),
        colorTheme: isNight
          ? { light: "from-slate-800 to-slate-900", dark: "from-slate-900 to-slate-950" }
          : { light: "from-slate-300 to-slate-200", dark: "from-slate-800 to-slate-700" },
      };
    case 45: // Fog
    case 48: // Depositing rime fog
      return {
        label: "Fog",
        icon: CloudFog,
        colorTheme: { light: "from-stone-300 to-stone-400", dark: "from-stone-700 to-stone-800" },
      };
    case 51: // Drizzle
    case 53:
    case 55:
    case 56: // Freezing Drizzle
    case 57:
      return {
        label: "Drizzle",
        icon: CloudDrizzle,
        colorTheme: { light: "from-blue-200 to-slate-300", dark: "from-blue-900 to-slate-800" },
      };
    case 61: // Rain
    case 63:
    case 65:
    case 66: // Freezing Rain
    case 67:
    case 80: // Rain showers
    case 81:
    case 82:
      return {
        label: "Rain",
        icon: CloudRain,
        colorTheme: { light: "from-indigo-300 to-slate-400", dark: "from-indigo-900 to-slate-800" },
      };
    case 71: // Snow fall
    case 73:
    case 75:
    case 77: // Snow grains
    case 85: // Snow showers
    case 86:
      return {
        label: "Snow",
        icon: Snowflake,
        colorTheme: { light: "from-blue-100 to-slate-200", dark: "from-slate-800 to-slate-900" },
      };
    case 95: // Thunderstorm
    case 96: // Thunderstorm with hail
    case 99:
      return {
        label: "Thunderstorm",
        icon: CloudLightning,
        colorTheme: { light: "from-purple-300 to-slate-500", dark: "from-purple-900 to-slate-900" },
      };
    default:
      return {
        label: "Unknown",
        icon: Cloud,
        colorTheme: { light: "from-slate-200 to-slate-300", dark: "from-slate-800 to-slate-900" },
      };
  }
}

export function formatTemp(tempC: number, unit: "C" | "F"): string {
  if (unit === "C") return `${Math.round(tempC)}°`;
  return `${Math.round((tempC * 9) / 5 + 32)}°`;
}

export function formatTime(isoString: string): string {
  const date = new Date(isoString);
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

export function formatDay(isoString: string): string {
  const date = new Date(isoString);
  return date.toLocaleDateString([], { weekday: 'short' });
}
